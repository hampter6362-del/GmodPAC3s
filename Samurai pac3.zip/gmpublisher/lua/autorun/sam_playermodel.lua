player_manager.AddValidModel( "Samurai", "models/Player/samurai.mdl" )
